<?php
// Heading
$_['heading_title']         = 'Products Purchased Report Advanced';

// Text
$_['text_list']             = 'Products Purchased List';
$_['text_all_status']       = 'All Statuses';

// Column
$_['column_country']        = 'Country';
$_['column_orders']         = 'No. Orders';
$_['column_total']          = 'Total';
$_['column_email']          = 'Customer Email';
$_['column_country']        = 'Country';
$_['column_order_date']     = 'Order Date';
$_['column_order_status']     = 'Order Status';
$_['column_quantity']       = 'Quantity';
$_['column_customer_name']           = 'Customer Name';
$_['column_product_name']           = 'Product Name';
$_['column_model']           = 'Product Model';

// Entry
$_['entry_date_start']      = 'Date Start';
$_['entry_date_end']        = 'Date End';
$_['entry_status']          = 'Order Status';