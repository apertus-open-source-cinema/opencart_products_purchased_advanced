<?php
// Heading
$_['heading_title']         = 'Products Purchased Report Advanced';

// Text
$_['text_list']             = 'Products Purchased List';
$_['text_all_status']       = 'All Statuses';

// Column
$_['column_country']        = 'Country';
$_['column_orders']         = 'No. Orders';
$_['column_total']          = 'Total';

// Entry
$_['entry_date_start']      = 'Date Start';
$_['entry_date_end']        = 'Date End';
$_['entry_status']          = 'Order Status';